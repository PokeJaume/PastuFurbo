import json
import os
import time

import xbmc
import xbmcaddon
import xbmcvfs

from resources.lib import manifest

ADDON = xbmcaddon.Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
CACHE_FILE = os.path.join(PROFILE, "items_cache.json")
CACHE_TTL = 5 * 60  # 5 minutos


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[mifutbol] aggregator: {msg}", level)


def get_all():
    """Devuelve la lista combinada de items (canales + eventos) con cache
    persistente para no re-descargar en cada click."""
    try:
        if os.path.exists(CACHE_FILE):
            age = time.time() - os.path.getmtime(CACHE_FILE)
            if age < CACHE_TTL:
                with open(CACHE_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                _log(f"cache hit (age={int(age)}s, {len(data)} items)")
                return data
    except Exception as e:
        _log(f"cache lectura KO: {e}", xbmc.LOGWARNING)

    items = _fetch_all()

    try:
        os.makedirs(PROFILE, exist_ok=True)
        with open(CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(items, f)
        _log(f"cache escrito ({len(items)} items)")
    except Exception as e:
        _log(f"cache escritura KO: {e}", xbmc.LOGWARNING)

    return items


def _fetch_all():
    items = []
    try:
        cfg = manifest.load()
    except Exception as e:
        _log(f"manifest KO: {e}", xbmc.LOGERROR)
        return items

    for src_cfg in cfg.get("sources", []):
        name = src_cfg.get("name", "?")
        src_type = src_cfg.get("type", "generic")
        try:
            items.extend(_fetch_from(src_type, src_cfg))
            _log(f"fuente {name} ({src_type}) OK")
        except Exception as e:
            _log(f"fuente {name} ({src_type}) KO: {e}", xbmc.LOGWARNING)
    return items


def _fetch_from(src_type, src_cfg):
    if src_type == "demo":
        from resources.lib.sources import demo
        return demo.fetch_events()
    if src_type == "generic":
        from resources.lib.sources import generic
        return generic.fetch_events(src_cfg)
    if src_type == "json_links":
        from resources.lib.sources import json_links
        return json_links.fetch_events(src_cfg)
    if src_type == "markel":
        from resources.lib.sources import markel
        return markel.fetch_events(src_cfg)
    if src_type == "futbolenlatv":
        from resources.lib.sources import futbolenlatv
        return futbolenlatv.fetch_events(src_cfg)
    mod = __import__(
        f"resources.lib.sources.{src_type}",
        fromlist=[src_type],
    )
    return mod.fetch_events(src_cfg)
