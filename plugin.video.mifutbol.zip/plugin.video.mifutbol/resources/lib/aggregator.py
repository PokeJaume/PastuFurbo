import xbmc

from resources.lib import manifest


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[mifutbol] aggregator: {msg}", level)


def get_all():
    """Carga el manifest y agrega los eventos de cada fuente."""
    events = []
    try:
        cfg = manifest.load()
    except Exception as e:
        _log(f"manifest KO: {e}", xbmc.LOGERROR)
        return events

    for src_cfg in cfg.get("sources", []):
        name = src_cfg.get("name", "?")
        src_type = src_cfg.get("type", "generic")
        try:
            events.extend(_fetch_from(src_type, src_cfg))
            _log(f"fuente {name} ({src_type}) OK")
        except Exception as e:
            _log(f"fuente {name} ({src_type}) KO: {e}", xbmc.LOGWARNING)
    return events


def _fetch_from(src_type, src_cfg):
    if src_type == "demo":
        from resources.lib.sources import demo
        return demo.fetch_events()
    if src_type == "generic":
        from resources.lib.sources import generic
        return generic.fetch_events(src_cfg)
    if src_type == "json_links":
        from resources.lib.sources import json_links
        return json_links.fetch_events(src_cfg)
    # Hook para fuentes con logica propia (un .py por web)
    mod = __import__(
        f"resources.lib.sources.{src_type}",
        fromlist=[src_type],
    )
    return mod.fetch_events(src_cfg)
