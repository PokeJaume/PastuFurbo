from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import aggregator, matcher, player

HANDLE = None


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[mifutbol] {msg}", level)


def build_url(base, **kwargs):
    return f"{base}?{urlencode(kwargs)}"


def dispatch(argv):
    global HANDLE
    base_url = argv[0]
    HANDLE = int(argv[1])
    params = dict(parse_qsl(argv[2][1:])) if len(argv) > 2 and argv[2] else {}
    action = params.get("action", "root")

    log(f"dispatch action={action} params={params}")

    if action == "root":
        show_root(base_url)
    elif action == "agenda":
        show_competitions(base_url)
    elif action == "competition":
        show_matches_in_competition(base_url, params.get("name", ""))
    elif action == "match":
        show_match_options(base_url, params.get("id", ""))
    elif action == "channels":
        show_categories(base_url)
    elif action == "category":
        show_channels_in_category(base_url, params.get("name", ""))
    elif action == "all":
        show_all_channels(base_url)
    elif action == "play":
        play(params.get("id", ""), params.get("title", ""))
    else:
        show_root(base_url)


# ----- cache en memoria (dentro de la misma invocacion del plugin) -----

_items_cache = None

def _items():
    global _items_cache
    if _items_cache is None:
        try:
            _items_cache = aggregator.get_all()
        except Exception as e:
            log(f"aggregator error: {e}", xbmc.LOGERROR)
            _items_cache = []
    return _items_cache


def _channels():
    return [i for i in _items() if i.get("ids")]


def _events():
    return [i for i in _items() if i.get("channel_names") is not None]


# ----- root -----

def show_root(base_url):
    xbmcplugin.setPluginCategory(HANDLE, "Pastu Furbo")
    xbmcplugin.setContent(HANDLE, "videos")

    evs = _events()
    chs = _channels()

    li = xbmcgui.ListItem(label=f"[B]AGENDA[/B]  (partidos de hoy, {len(evs)})")
    xbmcplugin.addDirectoryItem(HANDLE, build_url(base_url, action="agenda"), li, isFolder=True)

    li = xbmcgui.ListItem(label=f"[B]CANALES[/B]  (por competicion, {len(chs)})")
    xbmcplugin.addDirectoryItem(HANDLE, build_url(base_url, action="channels"), li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


# ----- AGENDA -----

def show_competitions(base_url):
    xbmcplugin.setPluginCategory(HANDLE, "Agenda - Competiciones")
    xbmcplugin.setContent(HANDLE, "videos")

    evs = _events()
    comps = {}
    order = []
    for ev in evs:
        c = ev.get("competition") or "Sin competicion"
        if c not in comps:
            comps[c] = 0
            order.append(c)
        comps[c] += 1

    if not order:
        li = xbmcgui.ListItem(label="(sin eventos hoy)")
        xbmcplugin.addDirectoryItem(HANDLE, "", li, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for c in order:
        label = f"{c}  ({comps[c]})"
        li = xbmcgui.ListItem(label=label)
        xbmcplugin.addDirectoryItem(
            HANDLE,
            build_url(base_url, action="competition", name=c),
            li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(HANDLE)


def show_matches_in_competition(base_url, comp_name):
    xbmcplugin.setPluginCategory(HANDLE, comp_name)
    xbmcplugin.setContent(HANDLE, "videos")

    evs = _events()
    for i, ev in enumerate(evs):
        if (ev.get("competition") or "Sin competicion") != comp_name:
            continue
        time_str = ev.get("time", "--:--")
        title = ev.get("title", "?")
        ch_count = len(ev.get("channel_names") or [])
        label = f"{time_str}  {title}  [{ch_count} canal(es)]"
        li = xbmcgui.ListItem(label=label)
        li.setInfo("video", {"title": f"{title} ({time_str})", "plot": f"Competicion: {comp_name}"})
        xbmcplugin.addDirectoryItem(
            HANDLE,
            build_url(base_url, action="match", id=str(i)),
            li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(HANDLE)


def show_match_options(base_url, match_idx_str):
    try:
        idx = int(match_idx_str)
    except ValueError:
        idx = -1
    evs = _events()
    if idx < 0 or idx >= len(evs):
        xbmcplugin.endOfDirectory(HANDLE)
        return
    ev = evs[idx]
    xbmcplugin.setPluginCategory(HANDLE, ev.get("title", "?"))
    xbmcplugin.setContent(HANDLE, "videos")

    channel_names = ev.get("channel_names") or []
    chs = _channels()
    matched = matcher.match_channels(channel_names, chs)

    any_added = False
    for ch_name, mk_list in matched:
        if not mk_list:
            # Mostrar como item inactivo (informativo)
            li = xbmcgui.ListItem(label=f"[COLOR gray]{ch_name} (sin acestream)[/COLOR]")
            xbmcplugin.addDirectoryItem(HANDLE, "", li, isFolder=False)
            continue
        for mk in mk_list:
            img = mk.get("img")
            for i, ace_id in enumerate(mk.get("ids") or [], start=1):
                any_added = True
                ch_label = mk.get("title", "?")
                opt = f"Opcion {i}" if len(mk.get("ids") or []) > 1 else ""
                label = f"[{ch_name}]  {ch_label}  {opt}".strip()
                li = xbmcgui.ListItem(label=label)
                li.setInfo("video", {"title": ev.get("title", "?"), "plot": f"Canal: {ch_label}\nAnunciado como: {ch_name}"})
                if img:
                    li.setArt({"icon": img, "thumb": img, "poster": img})
                li.setProperty("IsPlayable", "true")
                xbmcplugin.addDirectoryItem(
                    HANDLE,
                    build_url(base_url, action="play", id=ace_id, title=ev.get("title", "?")),
                    li,
                    isFolder=False,
                )
    if not any_added and not channel_names:
        li = xbmcgui.ListItem(label="(sin canales anunciados)")
        xbmcplugin.addDirectoryItem(HANDLE, "", li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


# ----- CANALES -----

def show_categories(base_url):
    xbmcplugin.setPluginCategory(HANDLE, "Canales por competicion")
    xbmcplugin.setContent(HANDLE, "videos")

    chs = _channels()
    cats = {}
    order = []
    for c in chs:
        prov = c.get("provider") or "Otros"
        if prov not in cats:
            cats[prov] = {"channels": 0, "options": 0}
            order.append(prov)
        cats[prov]["channels"] += 1
        cats[prov]["options"] += len(c.get("ids") or [])

    total_ch = sum(v["channels"] for v in cats.values())
    total_op = sum(v["options"] for v in cats.values())
    li_all = xbmcgui.ListItem(label=f"[B]Todos los canales[/B]  ({total_ch} canales, {total_op} opciones)")
    xbmcplugin.addDirectoryItem(HANDLE, build_url(base_url, action="all"), li_all, isFolder=True)

    for prov in order:
        info = cats[prov]
        label = f"{prov}  ({info['channels']} canales)"
        li = xbmcgui.ListItem(label=label)
        xbmcplugin.addDirectoryItem(
            HANDLE,
            build_url(base_url, action="category", name=prov),
            li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(HANDLE)


def show_channels_in_category(base_url, cat_name):
    xbmcplugin.setPluginCategory(HANDLE, cat_name)
    xbmcplugin.setContent(HANDLE, "videos")
    for c in _channels():
        if (c.get("provider") or "Otros") != cat_name:
            continue
        _add_channel_options(base_url, c)
    xbmcplugin.endOfDirectory(HANDLE)


def show_all_channels(base_url):
    xbmcplugin.setPluginCategory(HANDLE, "Todos los canales")
    xbmcplugin.setContent(HANDLE, "videos")
    for c in _channels():
        _add_channel_options(base_url, c)
    xbmcplugin.endOfDirectory(HANDLE)


def _add_channel_options(base_url, ch):
    ids = ch.get("ids") or []
    img = ch.get("img")
    title = ch.get("title", "?")
    for i, ace_id in enumerate(ids, start=1):
        label = f"{title}  -  Opcion {i}" if len(ids) > 1 else title
        li = xbmcgui.ListItem(label=label)
        li.setInfo("video", {"title": title})
        if img:
            li.setArt({"icon": img, "thumb": img, "poster": img})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(
            HANDLE,
            build_url(base_url, action="play", id=ace_id, title=title),
            li,
            isFolder=False,
        )


# ----- play -----

def play(ace_id, title):
    player.play(HANDLE, ace_id, title)
