from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import aggregator, player

HANDLE = None


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[mifutbol] {msg}", level)


def build_url(base, **kwargs):
    return f"{base}?{urlencode(kwargs)}"


def dispatch(argv):
    global HANDLE
    base_url = argv[0]
    HANDLE = int(argv[1])
    params = dict(parse_qsl(argv[2][1:])) if len(argv) > 2 and argv[2] else {}
    action = params.get("action", "root")

    log(f"dispatch action={action} params={params}")

    if action == "root":
        show_root(base_url)
    elif action == "events":
        show_events(base_url)
    elif action == "play":
        play(params.get("id", ""), params.get("title", ""))
    else:
        show_root(base_url)


def show_root(base_url):
    xbmcplugin.setPluginCategory(HANDLE, "Mi Futbol")
    xbmcplugin.setContent(HANDLE, "videos")

    items = [
        ("Partidos de hoy", build_url(base_url, action="events")),
    ]
    for label, url in items:
        li = xbmcgui.ListItem(label=label)
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def show_events(base_url):
    xbmcplugin.setPluginCategory(HANDLE, "Partidos")
    xbmcplugin.setContent(HANDLE, "videos")

    events = aggregator.get_all()

    if not events:
        li = xbmcgui.ListItem(label="(sin eventos)")
        xbmcplugin.addDirectoryItem(HANDLE, "", li, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for ev in events:
        for i, ace_id in enumerate(ev["ids"], start=1):
            label = f"[{ev['time']}] {ev['title']} - Enlace {i} ({ev['source']})"
            url = build_url(
                base_url,
                action="play",
                id=ace_id,
                title=ev["title"],
            )
            li = xbmcgui.ListItem(label=label)
            li.setInfo("video", {
                "title": ev["title"],
                "plot": f"Fuente: {ev['source']}\nHora: {ev['time']}",
            })
            li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def play(ace_id, title):
    player.play(HANDLE, ace_id, title)
