"""Cruza nombres de canal (de fuentes tipo agenda) con canales que tienen
acestream IDs (de fuentes tipo markel). Devuelve, para cada nombre entrante,
la lista de canales que encajan y sus acestream IDs."""

import re


def _norm(s):
    s = s.lower()
    # Quitar parentesis con su contenido (ej "DAZN (Ver en directo)" -> "DAZN")
    s = re.sub(r"\([^)]*\)", " ", s)
    # Normalizar algunos simbolos
    s = s.replace("+", " plus ")
    s = re.sub(r"[^a-z0-9 ]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


# Reglas: (patron_para_canal_entrante, patron_para_canal_markel)
# Se evalua en orden; la PRIMERA que casa el canal entrante es la que decide
# que canales markel se devuelven (resto se ignora para ese entrante).
# Despues de _norm "M+" -> "m plus", "M+ LALIGA" -> "m plus laliga".
ALIASES = [
    # Mas especifico primero
    (r"\bhypermotion\b|\blaliga tv\b|laliga tv bar",
     r"\bhypermotion\b"),

    (r"\bdazn laliga\b",
     r"\bdazn laliga\b"),

    (r"\bdazn f1\b|\bdazn formula\b",
     r"\bdazn f1\b|dazn formula"),

    (r"\bdazn motogp\b|\bdazn moto\b",
     r"\bdazn motogp\b|dazn moto"),

    (r"liga endesa|dazn baloncesto|dazn endesa",
     r"endesa|baloncesto"),

    (r"liga de campeones|\bchampions\b|l de campeones|m plus l de campeones",
     r"campeones|champions"),

    (r"m plus laliga|movistar laliga",
     r"m plus laliga|movistar laliga"),

    (r"\beurosport\b",
     r"\beurosport\b"),

    (r"\bteledeporte\b", r"\bteledeporte\b"),
    (r"\bla 1\b",       r"\bla 1\b"),
    (r"\bla 2\b",       r"\bla 2\b"),
    (r"\bantena 3\b",   r"\bantena 3\b"),
    (r"\btelecinco\b",  r"\btelecinco\b"),
    (r"\bcuatro\b",     r"\bcuatro\b"),
    (r"\bgol\b",        r"\bgol\b"),
    (r"\bbein\b",       r"\bbein\b"),

    # Movistar Plus+ general
    (r"movistar plus|m plus 1|m plus 2|m plus plus",
     r"movistar plus|m plus plus|m plus$"),

    # DAZN generico AL FINAL: solo DAZN 1/2/3/4 (canales lineales)
    (r"\bdazn\b",
     r"\bdazn \d\b|\bdazn bar\b"),
]

COMPILED = [(re.compile(a), re.compile(b)) for a, b in ALIASES]


def match_channels(channel_names, markel_channels):
    """Dado una lista de nombres de canal y una lista de canales markel
    (dicts con title, tags, ids, img, provider), devuelve
    [(channel_name, [matched_markel_items])].

    Un mismo canal markel puede aparecer bajo varios channel_names.
    Si no hay match, el canal_name aparece con lista vacia.
    """
    markel_norm = []
    for c in markel_channels:
        title_norm = _norm(c.get("title", ""))
        tags_norm = _norm(c.get("tags", ""))
        haystack = f"{title_norm} {tags_norm}".strip()
        markel_norm.append((haystack, c))

    out = []
    for ch_name in channel_names:
        ch_norm = _norm(ch_name)
        matches = []
        for name_re, markel_re in COMPILED:
            if name_re.search(ch_norm):
                for haystack, mk in markel_norm:
                    if markel_re.search(haystack) and mk not in matches:
                        matches.append(mk)
                break  # primera regla que casa gana
        out.append((ch_name, matches))
    return out
