import socket

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

ADDON = xbmcaddon.Addon()

INTENT_PACKAGE_CANDIDATES = [
    "org.acestream.media",
    "org.acestream.engine",
    "org.acestream.core",
    "org.acestream.media.atv",
]


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[mifutbol] player: {msg}", level)


def play(handle, ace_id, title):
    method = ADDON.getSetting("player_method") or "engine_http"
    _log(f"play id={ace_id} title={title} method={method}")

    if not ace_id or len(ace_id) != 40:
        xbmcgui.Dialog().ok("Pastu Furbo", f"ID Acestream invalido:\n{ace_id}")
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    if method == "horus":
        _play_horus(handle, ace_id, title)
        return

    if method == "intent":
        _play_intent(handle, ace_id, title)
        return

    # engine_http (default)
    if _engine_available():
        _log("motor HTTP responde, pidiendo playback_url")
        _play_engine_http(handle, ace_id, title)
    else:
        _log("motor HTTP NO responde, probando intent", xbmc.LOGWARNING)
        xbmcgui.Dialog().notification(
            "Pastu Furbo",
            "Motor Acestream no responde, usando app",
            xbmcgui.NOTIFICATION_WARNING, 3000,
        )
        _play_intent(handle, ace_id, title)


def _engine_host():
    val = (ADDON.getSetting("engine_host") or "").strip()
    return val or "127.0.0.1:6878"


def _engine_available():
    host_port = _engine_host()
    try:
        host, port_str = host_port.split(":", 1)
        port = int(port_str)
    except Exception:
        host, port = host_port, 6878
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1.5)
        s.connect((host, port))
        s.close()
        return True
    except Exception as e:
        _log(f"engine check KO ({host}:{port}): {e}")
        return False


def _candidate_packages():
    override = (ADDON.getSetting("intent_package") or "").strip()
    if override:
        return [override]
    return list(INTENT_PACKAGE_CANDIDATES)


def _play_engine_http(handle, ace_id, title):
    """Pide al engine la playback_url real y se la pasa a Kodi."""
    host = _engine_host()
    api_url = f"http://{host}/ace/getstream?id={ace_id}&format=json"
    _log(f"engine API pedida: {api_url}")

    playback_url = None
    err = None
    try:
        import requests
        resp = requests.get(api_url, timeout=20)
        resp.raise_for_status()
        try:
            data = resp.json()
        except ValueError:
            data = None

        if data is not None:
            api_error = data.get("error")
            if api_error:
                err = str(api_error)
            else:
                response_obj = data.get("response") or {}
                playback_url = response_obj.get("playback_url")
                _log(f"playback_url recibida: {playback_url}")
        else:
            # Si no devuelve JSON, el body puede ser ya la URL o el stream
            body = (resp.text or "").strip()
            if body.startswith("http"):
                playback_url = body
            else:
                err = "respuesta del engine no reconocible"
    except Exception as e:
        err = str(e)
        _log(f"engine API KO: {e}", xbmc.LOGWARNING)

    if not playback_url:
        xbmcgui.Dialog().notification(
            "Pastu Furbo",
            f"Engine no da stream: {err or 'sin playback_url'}",
            xbmcgui.NOTIFICATION_ERROR, 5000,
        )
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    _log(f"reproduciendo {playback_url}")
    li = xbmcgui.ListItem(label=title, path=playback_url)
    li.setInfo("video", {"title": title})
    xbmcplugin.setResolvedUrl(handle, True, li)


def _play_intent(handle, ace_id, title):
    override = (ADDON.getSetting("intent_package") or "").strip()
    pkg = override if override else ""
    cmd = (
        f'StartAndroidActivity('
        f'"{pkg}",'
        '"android.intent.action.VIEW",'
        '"",'
        f'"acestream://{ace_id}"'
        ')'
    )
    _log(f"intent pkg={pkg or '<auto>'} cmd={cmd}")
    xbmc.executebuiltin(cmd)
    xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())


def _play_horus(handle, ace_id, title):
    url = f"plugin://script.module.horus/?mode=1&url={ace_id}&name={title}"
    li = xbmcgui.ListItem(label=title, path=url)
    li.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(handle, True, li)
