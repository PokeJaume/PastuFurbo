import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

ADDON = xbmcaddon.Addon()


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[mifutbol] {msg}", level)


def play(handle, ace_id, title):
    method = ADDON.getSetting("player_method") or "engine_http"
    _log(f"play id={ace_id} title={title} method={method}")

    if not ace_id or len(ace_id) != 40:
        xbmcgui.Dialog().ok("Pastu Furbo", f"ID Acestream invalido:\n{ace_id}")
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    if method == "horus":
        _play_horus(handle, ace_id, title)
    elif method == "intent":
        _play_intent(handle, ace_id, title)
    else:
        _play_engine_http(handle, ace_id, title)


def _engine_host():
    """Host:port del motor Acestream (por defecto 127.0.0.1:6878)."""
    val = (ADDON.getSetting("engine_host") or "").strip()
    return val or "127.0.0.1:6878"


def _play_engine_http(handle, ace_id, title):
    """Reproduce dentro de Kodi usando la API HTTP del motor Acestream.

    Requiere que el motor este corriendo. En Android con 'Ace Stream Media'
    instalado, basta con abrir la app una vez para que arranque el servicio
    en 127.0.0.1:6878.
    """
    url = f"http://{_engine_host()}/ace/getstream?id={ace_id}"
    _log(f"engine_http url={url}")
    li = xbmcgui.ListItem(label=title, path=url)
    li.setInfo("video", {"title": title})
    xbmcplugin.setResolvedUrl(handle, True, li)


def _play_intent(handle, ace_id, title):
    """Lanza la app oficial de Ace Stream por intent de Android.

    La reproduccion sale de Kodi y se abre en Ace Stream Media. Kodi puede
    mostrar un aviso cosmetico de 'playback failed' pero la app igualmente
    arranca.
    """
    cmd = (
        'StartAndroidActivity('
        '"org.acestream.media",'
        '"android.intent.action.VIEW",'
        '"",'
        f'"acestream://{ace_id}"'
        ')'
    )
    _log(f"intent cmd={cmd}")
    xbmc.executebuiltin(cmd)
    xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())


def _play_horus(handle, ace_id, title):
    """Resuelve usando Horus (si lo tienes instalado como dependencia opcional)."""
    url = f"plugin://script.module.horus/?mode=1&url={ace_id}&name={title}"
    li = xbmcgui.ListItem(label=title, path=url)
    li.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(handle, True, li)
