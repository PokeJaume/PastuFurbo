import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

ADDON = xbmcaddon.Addon()


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[mifutbol] {msg}", level)


def play(handle, ace_id, title):
    method = ADDON.getSetting("player_method") or "intent"
    _log(f"play id={ace_id} title={title} method={method}")

    if not ace_id or len(ace_id) != 40:
        xbmcgui.Dialog().ok("Mi Futbol", f"ID Acestream invalido:\n{ace_id}")
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    if method == "horus":
        _play_horus(handle, ace_id, title)
    else:
        _play_intent(handle, ace_id, title)


def _play_intent(handle, ace_id, title):
    """Lanza la app oficial de Ace Stream por intent de Android.

    La reproduccion sale de Kodi y se abre en Ace Stream Media.
    Requiere el paquete org.acestream.media instalado en el TV box.
    """
    cmd = (
        'StartAndroidActivity('
        '"org.acestream.media",'
        '"android.intent.action.VIEW",'
        '"",'
        f'"acestream://{ace_id}"'
        ')'
    )
    _log(f"intent cmd={cmd}")
    xbmc.executebuiltin(cmd)
    xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())


def _play_horus(handle, ace_id, title):
    """Resuelve dentro de Kodi usando Horus (recomendado si lo tienes instalado).

    Horus habla con el motor Acestream por HTTP y devuelve un HLS que Kodi
    reproduce con su reproductor nativo.
    """
    url = f"plugin://script.module.horus/?mode=1&url={ace_id}&name={title}"
    li = xbmcgui.ListItem(label=title, path=url)
    li.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(handle, True, li)
