import socket

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

ADDON = xbmcaddon.Addon()

# Packages Android candidatos para el intent VIEW de acestream://.
# Se prueban en orden si el usuario no especifica uno en los ajustes.
INTENT_PACKAGE_CANDIDATES = [
    "org.acestream.media",         # Ace Stream Media (app completa)
    "org.acestream.engine",        # Ace Stream Engine (solo motor)
    "org.acestream.core",          # version antigua
    "org.acestream.media.atv",     # variante Android TV
]


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[mifutbol] player: {msg}", level)


def play(handle, ace_id, title):
    method = ADDON.getSetting("player_method") or "engine_http"
    _log(f"play id={ace_id} title={title} method={method}")

    if not ace_id or len(ace_id) != 40:
        xbmcgui.Dialog().ok("Pastu Furbo", f"ID Acestream invalido:\n{ace_id}")
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    if method == "horus":
        _play_horus(handle, ace_id, title)
        return

    if method == "intent":
        _play_intent(handle, ace_id, title)
        return

    # method == engine_http (default).
    if _engine_available():
        _log("motor HTTP responde, reproduciendo en Kodi")
        _play_engine_http(handle, ace_id, title)
    else:
        _log("motor HTTP NO responde, probando intent", xbmc.LOGWARNING)
        xbmcgui.Dialog().notification(
            "Pastu Furbo",
            "Motor Acestream no responde, usando app",
            xbmcgui.NOTIFICATION_WARNING, 3000,
        )
        _play_intent(handle, ace_id, title)


def _engine_host():
    val = (ADDON.getSetting("engine_host") or "").strip()
    return val or "127.0.0.1:6878"


def _engine_available():
    host_port = _engine_host()
    try:
        host, port_str = host_port.split(":", 1)
        port = int(port_str)
    except Exception:
        host, port = host_port, 6878
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1.5)
        s.connect((host, port))
        s.close()
        return True
    except Exception as e:
        _log(f"engine check KO ({host}:{port}): {e}")
        return False


def _candidate_packages():
    override = (ADDON.getSetting("intent_package") or "").strip()
    if override:
        return [override]
    return list(INTENT_PACKAGE_CANDIDATES)


def _play_engine_http(handle, ace_id, title):
    url = f"http://{_engine_host()}/ace/getstream?id={ace_id}"
    _log(f"engine_http url={url}")
    li = xbmcgui.ListItem(label=title, path=url)
    li.setInfo("video", {"title": title})
    xbmcplugin.setResolvedUrl(handle, True, li)


def _play_intent(handle, ace_id, title):
    """Lanza el intent VIEW sobre acestream://<id>.

    Por defecto package vacio: Android elige la app que maneja ese esquema
    (ideal cuando el package exacto no se conoce o varia por version).
    Si el usuario ha puesto un package en ajustes, se usa ese.
    """
    override = (ADDON.getSetting("intent_package") or "").strip()
    pkg = override if override else ""
    cmd = (
        f'StartAndroidActivity('
        f'"{pkg}",'
        '"android.intent.action.VIEW",'
        '"",'
        f'"acestream://{ace_id}"'
        ')'
    )
    _log(f"intent pkg={pkg or '<auto>'} cmd={cmd}")
    xbmc.executebuiltin(cmd)
    xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())


def _play_horus(handle, ace_id, title):
    url = f"plugin://script.module.horus/?mode=1&url={ace_id}&name={title}"
    li = xbmcgui.ListItem(label=title, path=url)
    li.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(handle, True, li)
