import json
import os
import time

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo("path")
PROFILE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))

LOCAL_FALLBACK = os.path.join(ADDON_PATH, "resources", "sources.json")
CACHE_FILE = os.path.join(PROFILE_PATH, "manifest_cache.json")
CACHE_TTL_SECONDS = 10 * 60  # 10 minutos

# URL por defecto (Gist). Se usa cuando el setting manifest_url esta vacio.
# Siempre apunta a la version mas reciente del Gist (sin hash de commit).
DEFAULT_MANIFEST_URL = (
    "https://gist.githubusercontent.com/PokeJaume/"
    "d6c0efa1bd9bfd94a29184c05a2cd42c/raw/sources.json"
)


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[mifutbol] manifest: {msg}", level)


def load():
    """Devuelve el dict de configuracion con la lista de fuentes.

    Orden de preferencia:
      1. URL remota si esta configurada y no cacheada demasiado tiempo.
      2. Cache local reciente (si la remota falla).
      3. sources.json empaquetado con el addon.
    """
    remote_url = (ADDON.getSetting("manifest_url") or "").strip() or DEFAULT_MANIFEST_URL

    if remote_url:
        cached = _read_cache_if_fresh()
        if cached is not None:
            _log("usando cache fresca")
            return cached
        fetched = _fetch_remote(remote_url)
        if fetched is not None:
            _write_cache(fetched)
            return fetched
        cached_any = _read_cache_if_fresh(force=True)
        if cached_any is not None:
            _log("remoto KO, uso cache vieja")
            return cached_any

    _log(f"uso fallback local {LOCAL_FALLBACK}")
    with open(LOCAL_FALLBACK, "r", encoding="utf-8") as f:
        return json.load(f)


def _fetch_remote(url):
    try:
        import requests
    except ImportError:
        _log("script.module.requests no disponible", xbmc.LOGWARNING)
        return None
    try:
        resp = requests.get(url, timeout=8)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        _log(f"error remoto: {e}", xbmc.LOGWARNING)
        return None


def _read_cache_if_fresh(force=False):
    if not os.path.exists(CACHE_FILE):
        return None
    try:
        age = time.time() - os.path.getmtime(CACHE_FILE)
        if not force and age > CACHE_TTL_SECONDS:
            return None
        with open(CACHE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        _log(f"cache ilegible: {e}", xbmc.LOGWARNING)
        return None


def _write_cache(data):
    try:
        if not os.path.exists(PROFILE_PATH):
            os.makedirs(PROFILE_PATH, exist_ok=True)
        with open(CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f)
    except Exception as e:
        _log(f"no se pudo escribir cache: {e}", xbmc.LOGWARNING)
