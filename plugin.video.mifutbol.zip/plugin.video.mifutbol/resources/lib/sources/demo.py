NAME = "demo"


def fetch_events():
    """Fuente de prueba con eventos inventados para validar el esqueleto."""
    return [
        {
            "title": "Real Madrid vs Barcelona",
            "time": "21:00",
            "ids": [
                "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
                "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
            ],
            "source": NAME,
        },
        {
            "title": "Atletico vs Sevilla",
            "time": "18:30",
            "ids": [
                "cccccccccccccccccccccccccccccccccccccccc",
            ],
            "source": NAME,
        },
        {
            "title": "Valencia vs Villarreal",
            "time": "16:15",
            "ids": [
                "dddddddddddddddddddddddddddddddddddddddd",
            ],
            "source": NAME,
        },
    ]
