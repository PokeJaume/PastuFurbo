"""Utilidades para ver y compartir kodi.log desde dentro del addon."""

import xbmc
import xbmcgui
import xbmcvfs

MAX_SHOW_LINES = 300
MAX_UPLOAD_BYTES = 1_500_000  # 1.5 MB (paste.kodi.tv limita a ~2MB)


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[mifutbol] logs: {msg}", level)


def _find_log():
    for name in ("kodi.log", "kodi.old.log"):
        path = xbmcvfs.translatePath(f"special://logpath/{name}")
        if xbmcvfs.exists(path):
            return path, name
    return None, None


def _read_log(path):
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    except Exception as e:
        return f"[error leyendo {path}: {e}]"


def show_log():
    """Muestra las lineas relevantes de kodi.log en un TextViewer."""
    path, name = _find_log()
    if not path:
        xbmcgui.Dialog().ok("Pastu Furbo", "No encuentro kodi.log en special://logpath/")
        return
    text = _read_log(path)
    lines = text.splitlines()
    # Nos quedamos con [mifutbol] + errores de los ultimos N lineas
    tail = lines[-5000:]
    relevant = [
        ln for ln in tail
        if "[mifutbol]" in ln
        or " ERROR" in ln
        or " FATAL" in ln
        or "Traceback" in ln
        or "Exception" in ln
    ]
    if not relevant:
        relevant = tail[-MAX_SHOW_LINES:]
    else:
        relevant = relevant[-MAX_SHOW_LINES:]
    body = "\n".join(relevant)
    header = f"Fichero: {name}  ({len(text)/1024:.0f} KB)\n----\n"
    xbmcgui.Dialog().textviewer("kodi.log (ultimas lineas filtradas)", header + body)


def upload_log():
    """Sube kodi.log a paste.kodi.tv y muestra la URL."""
    try:
        import requests
    except ImportError:
        xbmcgui.Dialog().ok("Pastu Furbo", "Falta script.module.requests")
        return

    path, name = _find_log()
    if not path:
        xbmcgui.Dialog().ok("Pastu Furbo", "No encuentro kodi.log en special://logpath/")
        return

    text = _read_log(path)
    # Si pasa de 1.5 MB cortamos las lineas antiguas
    if len(text.encode("utf-8", errors="ignore")) > MAX_UPLOAD_BYTES:
        text = text[-MAX_UPLOAD_BYTES:]
        text = "[... truncado al final ...]\n" + text

    progress = xbmcgui.DialogProgress()
    progress.create("Pastu Furbo", "Subiendo kodi.log a paste.kodi.tv...")
    progress.update(10)

    url = None
    error = None
    try:
        resp = requests.post(
            "https://paste.kodi.tv/documents",
            data=text.encode("utf-8", errors="ignore"),
            headers={"User-Agent": "PastuFurbo-LogUploader"},
            timeout=20,
        )
        progress.update(80)
        resp.raise_for_status()
        key = resp.json().get("key")
        if key:
            url = f"https://paste.kodi.tv/{key}"
    except Exception as e:
        error = str(e)
        _log(f"upload KO: {e}", xbmc.LOGWARNING)
    finally:
        progress.close()

    if url:
        xbmcgui.Dialog().ok(
            "Log subido",
            f"Copia esta URL y pasasela al desarrollador:\n\n{url}",
        )
    else:
        xbmcgui.Dialog().ok(
            "Error subiendo",
            f"No he podido subir el log.\n\nDetalle: {error or 'respuesta vacia'}",
        )
