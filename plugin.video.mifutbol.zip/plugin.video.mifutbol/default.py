import os
import sys

sys.path.insert(0, os.path.dirname(os.path.realpath(__file__)))

from resources.lib import router

if __name__ == "__main__":
    router.dispatch(sys.argv)
